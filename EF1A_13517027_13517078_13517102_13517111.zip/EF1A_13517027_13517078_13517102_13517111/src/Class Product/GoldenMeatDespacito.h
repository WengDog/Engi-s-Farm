#ifndef GOLDENMEATDESPACITO_H_INCLUDED
#define GOLDENMEATDESPACITO_H_INCLUDED

#include "SideProduct.h"

// Produk sampingan hasil dari telur bebek, daging sapi dan susu kuda
class GoldenMeatDespacito : public SideProduct {
    public:
        // ctor default
        GoldenMeatDespacito();
};

#endif // GOLDENMEATDESPACITO_H_INCLUDED
