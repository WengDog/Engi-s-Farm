#ifndef FARMPRODUCT_H_INCLUDED
#define FARMPRODUCT_H_INCLUDED

#include "Product.h"

class FarmProduct : public Product {
    public:
        // ctor default dengan mengimplementasikan ctor user defined pada kelas product
        FarmProduct();

};

#endif // FARMPRODUCT_H_INCLUDED
