#ifndef CARBONARA_H_INCLUDED
#define CARBONARA_H_INCLUDED

#include "SideProduct.h"

// Produk sampingan hasil dari daging kambing dan susu kuda
class Carbonara : public SideProduct {
    public:
        // ctor default dengan mengimplementasikan ctor user defined pada kelas product
        Carbonara();
};

#endif // CARBONARA_H_INCLUDED
