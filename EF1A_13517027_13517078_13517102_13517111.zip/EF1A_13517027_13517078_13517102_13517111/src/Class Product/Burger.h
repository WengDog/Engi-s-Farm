#ifndef BURGER_H_INCLUDED
#define BURGER_H_INCLUDED

#include "SideProduct.h"

// Produk sampingan hasil dari daging kelinci dan telur bebek
class Burger : public SideProduct {
    public:
        // ctor default
        Burger();
};

#endif // BURGER_H_INCLUDED
