#ifndef CHICKENEGG_H_INCLUDED
#define CHICKENEGG_H_INCLUDED

#include "FarmProduct.h"

// Produk hasil dari ayam
class ChickenEgg : public FarmProduct {
    public:
        // ctor default
        ChickenEgg();
};

#endif // CHICKENEGG_H_INCLUDED
