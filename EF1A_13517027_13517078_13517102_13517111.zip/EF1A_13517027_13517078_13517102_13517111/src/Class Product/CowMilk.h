#ifndef COWMILK_H_INCLUDED
#define COWMILK_H_INCLUDED

#include "FarmProduct.h"

class CowMilk : public FarmProduct {
    public:
        // ctor default
        CowMilk();
};

#endif // COWMILK_H_INCLUDED
