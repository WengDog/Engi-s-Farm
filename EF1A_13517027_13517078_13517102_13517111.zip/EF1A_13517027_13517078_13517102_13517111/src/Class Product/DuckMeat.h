#ifndef DUCKMEAT_H_INCLUDED
#define DUCKMEAT_H_INCLUDED

#include "FarmProduct.h"

class DuckMeat : public FarmProduct {
    public:
        // ctor default
        DuckMeat();
};

#endif // DUCKMEAT_H_INCLUDED
