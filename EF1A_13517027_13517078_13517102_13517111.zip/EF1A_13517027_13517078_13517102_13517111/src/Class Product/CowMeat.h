#ifndef COWMEAT_H_INCLUDED
#define COWMEAT_H_INCLUDED

#include "FarmProduct.h"

// Produk hasil dari sapi
class CowMeat : public FarmProduct {
    public:
        /// ctor default
        CowMeat();
};

#endif // COWMEAT_H_INCLUDED
