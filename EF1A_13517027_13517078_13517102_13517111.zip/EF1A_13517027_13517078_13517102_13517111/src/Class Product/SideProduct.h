#ifndef SIDEPRODUCT_H_INCLUDED
#define SIDEPRODUCT_H_INCLUDED

#include "Product.h"

class SideProduct : public Product {
    public:
        // ctor default dengan mengimplementasikan ctor user defined pada kelas product
        SideProduct();
};


#endif // SIDEPRODUCT_H_INCLUDED
