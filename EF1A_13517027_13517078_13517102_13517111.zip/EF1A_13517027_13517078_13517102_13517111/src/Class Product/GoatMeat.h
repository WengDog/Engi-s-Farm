#ifndef GOATMEAT_H_INCLUDED
#define GOATMEAT_H_INCLUDED

#include "FarmProduct.h"

// Produk hasil dari kambing
class GoatMeat : public FarmProduct {
    public:
        // ctor default
        GoatMeat();
};


#endif // GOATMEAT_H_INCLUDED
