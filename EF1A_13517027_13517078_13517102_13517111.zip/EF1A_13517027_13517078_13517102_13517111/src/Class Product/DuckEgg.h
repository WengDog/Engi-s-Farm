#ifndef DUCKEGG_H_INCLUDED
#define DUCKEGG_H_INCLUDED

#include "FarmProduct.h"

// Produk hasil dari bebek
class DuckEgg : public FarmProduct {
    public:
        // ctor default
        DuckEgg();
};

#endif // DUCKEGG_H_INCLUDED
