#ifndef PIESUSU_H_INCLUDED
#define PIESUSU_H_INCLUDED

#include "SideProduct.h"

// Produk sampingan hasil dari telur ayam dan susu sapi
class PieSusu : public SideProduct {
    public:
        // ctor default
        PieSusu();
};

#endif // PIESUSU_H_INCLUDED
