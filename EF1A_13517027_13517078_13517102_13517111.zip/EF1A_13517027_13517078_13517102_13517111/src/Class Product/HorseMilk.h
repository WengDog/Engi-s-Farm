#ifndef HORSEMILK_H_INCLUDED
#define HORSEMILK_H_INCLUDED

#include "FarmProduct.h"

class HorseMilk : public FarmProduct {
    public:
        // ctor default
        HorseMilk();
};

#endif // HORSEMILK_H_INCLUDED
