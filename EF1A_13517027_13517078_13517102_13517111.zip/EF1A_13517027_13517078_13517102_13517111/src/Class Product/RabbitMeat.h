#ifndef RABBITMEAT_H_INCLUDED
#define RABBITMEAT_H_INCLUDED

#include "FarmProduct.h"

// Produk hasil dari kelinci
class RabbitMeat : public FarmProduct {
    public:
        // ctor default
        RabbitMeat();
};

#endif // RABBITMEAT_H_INCLUDED
