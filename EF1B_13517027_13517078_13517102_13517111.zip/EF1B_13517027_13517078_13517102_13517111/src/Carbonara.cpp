// Implementasi kelas Carbonara

#include "Carbonara.h"

// ctor default dengan mengimplementasikan ctor user defined pada kelas product
Carbonara::Carbonara() {
    this->name = "Carbonara";
    this->Price = 25000;
}
