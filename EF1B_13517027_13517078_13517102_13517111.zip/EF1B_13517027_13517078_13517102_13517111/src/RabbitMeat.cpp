// Implementasi kelas RabbitMeat

#include "RabbitMeat.h"

// ctor default
RabbitMeat::RabbitMeat() {
    this->name = "Rabbit Meat";
    this->Price = 8000;
}
