// Implementasi kelas CowMilk

#include "CowMilk.h"

// ctor default
CowMilk::CowMilk() {
    this->name = "Cow Milk";
    this->Price = 10000;
}
