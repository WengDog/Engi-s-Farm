//Implementasi kelas DuckEgg

#include "DuckEgg.h"

// ctor default
DuckEgg::DuckEgg() {
    this->name = "Duck Egg";
    this->Price = 6000;
}
