// Implementasi kelas PieSusu

#include "PieSusu.h"

// ctor default
PieSusu::PieSusu() {
    this->name = "Pie Susu";
    this->Price = 20000;
}
