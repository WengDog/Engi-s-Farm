// Implementasi kelas DuckMeat

#include "DuckMeat.h"

// ctor default
DuckMeat::DuckMeat() {
    this->name = "Duck Meat";
    this->Price = 7000;
}
