// implementasi kelas Burger

#include "Burger.h"

// ctor default
Burger::Burger() {
    this->name = "Burger";
    this->Price = 20000;
}
