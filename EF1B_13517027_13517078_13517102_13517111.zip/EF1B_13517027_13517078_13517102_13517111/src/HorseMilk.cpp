// Implementasi kelas HorseMilk

#include "HorseMilk.h"

// ctor default
HorseMilk::HorseMilk() {
    this->name = "Horse Milk";
    this->Price = 13000;
}
