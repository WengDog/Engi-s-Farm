#include "MilkProducer.h"

using namespace std;

MilkProducer::MilkProducer(){
    this->milk = true;
}