// Implementasi kelas CowMeat

#include "CowMeat.h"

// ctor default
CowMeat::CowMeat() {
    this->name = "Cow Meat";
    this->Price = 10000;
}
