#include "EggProducer.h"

using namespace std;

EggProducer::EggProducer(){
    this->egg = true;
}