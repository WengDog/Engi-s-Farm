// Implementasi kelas ChickenEgg

#include "ChickenEgg.h"

// ctor default
ChickenEgg::ChickenEgg() {
    this->name = "Chicken Egg";
    this->Price = 5000;
}
