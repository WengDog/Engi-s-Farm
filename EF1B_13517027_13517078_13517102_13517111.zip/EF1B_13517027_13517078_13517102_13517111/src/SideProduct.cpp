// Implementasi kelas SideProduct

#include "SideProduct.h"

// ctor default dengan mengimplementasikan ctor user defined pada kelas product
SideProduct::SideProduct() : Product("\0",0,false,true){}
