// Implementasi kelas GoldenMeatDespacito

#include "GoldenMeatDespacito.h"

// ctor default
GoldenMeatDespacito::GoldenMeatDespacito() {
    this->name = "Golden Meat Despacito";
    this->Price = 50000;
}
