#include "MeatProducer.h"

using namespace std;

MeatProducer::MeatProducer(){
    this->meat = true;
}