// Implementasi kelas GoatMeat

#include "GoatMeat.h"

// ctor default
GoatMeat::GoatMeat() {
    this->name = "Goat Meat";
    this->Price = 12000;
}
