// Implementasi kelas FarmProduct

#include "FarmProduct.h"

// ctor default dengan mengimplementasikan ctor user defined pada kelas product
FarmProduct::FarmProduct() : Product("\0", 0, true,false){}
